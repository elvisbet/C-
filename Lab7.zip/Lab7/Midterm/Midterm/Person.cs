﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lab5_validation;

namespace Lab7
{
    public class Person//class(add the variables to class of public) as private
    {
        bool blnResult;
        private string firstName;
        private string middleName;
        private string lastName;
        private string street1;
        private string street2;
        private string city;
        private string state;
        private string zip;
        private string phone;
        private string email;
        public string feedback = "";

        int min;

        public string FirstName
        {//creating public variable based on the private variables      
            get
            {
                return firstName;//return value of the private variables 
            }
            set
            {
                if (ValidationLibrary.IsItFilledIn(value))
                {
                    firstName = value;

                    //asssigning value of the public string to the private
                }
                else
                {
                    feedback += "\nERROR: Enter Valid First Name_  ";//adding error message to feedback
                }
            }
        }
        public string MiddleName
        {
            get
            {
                return middleName;
            }
            set
            {
                if (ValidationLibrary.IsItFilledIn(value))//validating if the var is empty or value was added to it
                {
                    middleName = value;

                }
                else
                {
                    feedback += "\nERROR: Enter Valid Middle Name_  ";

                }
            }
        }
        public string LastName
        {
            get
            {
                return lastName;
            }
            set
            {
                //validating if the var is empty or value was added to it
                if (ValidationLibrary.IsItFilledIn(value))
                {
                    lastName = value;

                }
                else
                {
                    feedback += "\nERROR: Enter Valid Last Name_   ";
                }
            }

        }
        public string Street1
        {
            get
            {
                return street1;
            }
            set
            {
                //validating if the var is empty or value was added to it
                if (ValidationLibrary.IsItFilledIn(value))
                {
                    street1 = value;
                }
                else
                {
                    feedback += "\nERROR:Enter street_  ";
                }
            }
        }
        public string Street2
        {
            get
            {
                return street2;
            }
            set
            {
                street2 = value;
            }

        }

        public string Zip
        {
            get
            {

                return zip;
            }
            set
            {
                min = 5;
                if (ValidationLibrary.IsMinimumAmount(value, min))//validate the length of the zip if it is == 5;
                {

                    do
                    {
                        zip = value;
                    } while (blnResult == true);
                }
                else
                {
                    feedback += "\nERROR:Enter Valid Zipcode_  ";
                }

            }
        }
        public string City
        {
            get
            {
                return city;
            }
            set
            {
                if (ValidationLibrary.IsItFilledIn(value))
                {
                    city = value;
                }
            }
        }
        public string State
        {
            get
            {
                return state;
            }
            set
            {
                min = 2;
                if ((ValidationLibrary.Goodchar(value) == true) && (ValidationLibrary.IsMinimumAmount(value, min)))//Validate state contains a UPPER case 2-LETTER
                {
                    state = value;
                }
                else
                {
                    feedback += "\nERROR:Enter Valid State_  ";//displaying error in the feedback it does'nt pass validation
                }

            }
        }
        public string Phone
        {
            get
            {

                return phone;
            }
            set
            {
                min = 10;
                if (ValidationLibrary.IsMinimumAmount(value, min))
                {

                    do
                    {
                        phone = value;
                    } while (blnResult == true);
                }
                else
                {
                    feedback += "\nERROR:Enter Valid Phone _";
                }

            }
        }
        public string Email
        {
            get
            {
                return email;
            }
            set
            {
                if (ValidationLibrary.IsValidEmail(value))//Validate if Email has @ and . in it
                {
                    email = value;
                }
                else
                {
                    feedback += "\nERROR:Enter valid email_";
                }
            }
        }
        public string Feedback
        {
            get
            {
                return feedback;

            }
            set
            {
                if (feedback.Contains("ERROR:"))
                {
                    feedback += "";
                }
                else
                {
                    feedback = value;
                }

            }
        }
        public Person()//base()created from the Person2 class
        {
            firstName = "";
            middleName = "";
            lastName = "";
            street1 = "";
            street2 = "";
            city = "";
            state = "";
            zip = "";
            phone = "";
            email = "";
            feedback = "";

        }
    }
}
