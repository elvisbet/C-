﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lab5_validation;
using System.Data.SqlClient;

namespace Lab5
{
    class PersonV2 : Person//Inherits Person class
    {
        private string cell;
        private string instaurl;
        bool blnResult;
        int min;
        public string Cell//New property in the PersonV2
        {
            get
            {
                return cell;
            }
            set
            {
                min = 10;
                if (ValidationLibrary.IsMinimumAmount(value, min))//Validate if the Cellphone length is ==10
                {

                    do
                    {
                        cell = value;
                    } while (blnResult == true);
                }
                
                else
                {
                    feedback += "\nERROR:Enter Valid CellPhone  ";
                }

            }
        }

        public string Instaurl
        {
            get
            {
                return instaurl;
            }
            set
            {
                if (ValidationLibrary.IsValidUrl(value) == true)//Validating if the URL contains .
                {
                    instaurl = value;
                }
                else
                {
                    feedback += "\nERROR:Enter valid Instagram Url  ";
                }
            }
        }
        public string AddARecord()
        {
            //Init string var
            string strResult = "";

            //Make a connection object
            SqlConnection Conn = new SqlConnection();

            //Initialize it's properties
            Conn.ConnectionString = @"Server=sql.neit.edu\sqlstudentserver,4500;Database=SE245_EKibet;User Id=SE245_EKibet;Password=008009258;";     //Set the Who/What/Where of DB


            //*******************************************************************************************************
            // NEW
            //*******************************************************************************************************
            string strSQL = "INSERT INTO person2 (FirstName, MiddleName, LastName, Street1, Street2, City, StateName, Zip, Phone, Email, Cell, Instaurl) VALUES (@FirstName, @MiddleName, @LastName, @Street1, @Street2, @City, @StateName, @Zip, @Phone, @Email, @Cell, @Instaurl)";
            // Bark out our command
            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;  //Commander knows what to say
            comm.Connection = Conn;     //Where's the phone?  Here it is

            //Fill in the paramters (Has to be created in same sequence as they are used in SQL Statement)
            comm.Parameters.AddWithValue("@FirstName", FirstName);
            comm.Parameters.AddWithValue("@MiddleName", MiddleName);
            comm.Parameters.AddWithValue("@LastName", LastName);
            comm.Parameters.AddWithValue("@Street1", Street1);
            comm.Parameters.AddWithValue("@Street2", Street2);
            comm.Parameters.AddWithValue("@City", City);
            comm.Parameters.AddWithValue("@StateName", State);
            comm.Parameters.AddWithValue("@Zip", Zip);
            comm.Parameters.AddWithValue("@Phone", Phone);
            comm.Parameters.AddWithValue("@Email", Email);
            comm.Parameters.AddWithValue("@Cell", Cell);
            comm.Parameters.AddWithValue("@Instaurl", Instaurl);


            //*******************************************************************************************************





            //attempt to connect to the server
            try
            {
                Conn.Open();                                        //Open connection to DB - Think of dialing a friend on phone
                int intRecs = comm.ExecuteNonQuery();
                strResult = $"SUCCESS: Inserted {intRecs} records.";       //Report that we made the connection and added a record
                Conn.Close();                                       //Hanging up after phone call
            }
            catch (Exception err)                                   //If we got here, there was a problem connecting to DB
            {
                strResult = "ERROR: " + err.Message;                //Set feedback to state there was an error & error info
            }
            finally
            {

            }



            //Return resulting feedback string
            return strResult;
        }

        public PersonV2(): base()//add the property to the Base ;Person
        {
            cell = "";
            instaurl = "";
        }
    }
}
